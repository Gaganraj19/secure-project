import os
import cv2
import sys
import random
import string
import smtplib
import pandas as pd
import time
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from flask import Flask, request, render_template, session, jsonify, Response, redirect

# Initialize Flask app
app = Flask(__name__, static_folder='static', template_folder='templates')
app.secret_key = 'replace_this_with_a_strong_secret_key'

# Create directories if they don't exist
output_dir = "captured_faces"
os.makedirs(output_dir, exist_ok=True)
registered_faces_dir = "registered_faces"
os.makedirs(registered_faces_dir, exist_ok=True)

# Camera setup
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
cap = cv2.VideoCapture(0)

# Make sure the camera is properly initialized and reinitialized if needed
def ensure_camera_is_open():
    global cap
    
    # If camera isn't open or isn't reading frames properly, try to reinitialize it
    if not cap.isOpened():
        try:
            # Release the camera first if it exists but isn't working
            cap.release()
            # Reinitialize the camera
            cap = cv2.VideoCapture(0)
            
            # Check if the camera opened successfully
            if not cap.isOpened():
                print("Error: Could not reinitialize camera.")
                return False
                
            # Test if we can read a frame
            ret, _ = cap.read()
            if not ret:
                print("Error: Camera opened but cannot read frames.")
                cap.release()
                return False
                
            print("Camera successfully reinitialized.")
            return True
        except Exception as e:
            print(f"Exception while reinitializing camera: {e}")
            return False
    else:
        # Camera is already open, test if it's working
        try:
            ret, _ = cap.read()
            if ret:
                return True
            else:
                print("Error: Camera is open but cannot read frames.")
                # Try to reinitialize
                cap.release()
                cap = cv2.VideoCapture(0)
                return cap.isOpened()
        except Exception as e:
            print(f"Exception while testing camera: {e}")
            return False

# Email sending function
def send_email(to_email, subject, body):
    smtp_server = 'smtp.gmail.com'
    smtp_port = 587
    from_email = 'gaganraj774@gmail.com'  # Replace with your Gmail address
    password = 'htfy pszl nmif hsgk'       # Replace with your Gmail app password

    msg = MIMEMultipart()
    msg['From'] = from_email
    msg['To'] = to_email
    msg['Subject'] = subject
    msg.attach(MIMEText(body, 'plain'))

    try:
        server = smtplib.SMTP(smtp_server, smtp_port)
        server.starttls()
        server.login(from_email, password)
        server.sendmail(from_email, to_email, msg.as_string())
        print(f'Email successfully sent to {to_email}')
    except Exception as e:
        print(f'Failed to send email: {e}')
        raise
    finally:
        server.quit()

# OTP and CAPTCHA generation functions
def generate_otp(length=6):
    return ''.join(random.choices(string.digits, k=length))

def generate_captcha(length=6):
    chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789'
    return ''.join(random.choices(chars, k=length))

# Utility: load registered face images and compute their encodings for face comparison
def is_face_matching(test_img_path, registered_img_path, threshold=0.6):
    try:
        test_img = cv2.imread(test_img_path, cv2.IMREAD_GRAYSCALE)
        reg_img = cv2.imread(registered_img_path, cv2.IMREAD_GRAYSCALE)
        if test_img is None or reg_img is None:
            return False
        test_img = cv2.resize(test_img, (200, 200))
        reg_img = cv2.resize(reg_img, (200, 200))
        res = cv2.matchTemplate(test_img, reg_img, cv2.TM_CCOEFF_NORMED)
        min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res)
        return max_val >= threshold
    except Exception as e:
        print(f"Face matching error: {e}")
        return False

# Routes
@app.route('/')
def registration_form():
    captcha_code = generate_captcha()
    session['captcha'] = captcha_code
    return render_template('registration.html', captcha=captcha_code)

@app.route('/login_page')
def login_page():
    return render_template('login.html')

@app.route('/security_password')
def security_password_page():
    return render_template('security_password.html')

@app.route('/dashboard')
def dashboard():
    # In a real application, you would use session data instead of query parameters
    # and ensure proper authentication checks
    name = request.args.get('name', 'User')
    uid = request.args.get('uid', '')
    email = request.args.get('email', '')
    return render_template('dashboard.html', name=name, uid=uid, email=email)

@app.route('/send_otp', methods=['POST'])
def send_otp():
    data = request.get_json()
    email = data.get('email')
    if not email:
        return jsonify({'success': False, 'error': 'Email is required'}), 400
    try:
        otp_code = generate_otp()
        session['otp'] = otp_code
        subject = "Your OTP Code"
        body = f"Your OTP code is: {otp_code}"
        send_email(email, subject, body)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/refresh_captcha')
def refresh_captcha():
    new_captcha = generate_captcha()
    session['captcha'] = new_captcha
    return jsonify({'captcha': new_captcha})

@app.route('/register', methods=['POST'])
def register():
    name = request.form.get('name', '').strip()
    uid = request.form.get('uid', '').strip()
    email = request.form.get('email', '').strip()
    phone = request.form.get('phone', '').strip()
    password = request.form.get('password', '')
    confirm_password = request.form.get('confirm_password', '')
    user_otp = request.form.get('otp', '').strip()
    user_captcha = request.form.get('captcha', '').strip()
    
    if not all([name, uid, email, phone, password, confirm_password, user_otp, user_captcha]):
        return render_template('registration.html', captcha=session.get('captcha', ''), 
                            error="All fields including password, confirm password, OTP, and CAPTCHA are required.")
    
    if len(password) < 8:
        return render_template('registration.html', captcha=session.get('captcha', ''), 
                            error="Password must be at least 8 characters.")
    
    if password != confirm_password:
        return render_template('registration.html', captcha=session.get('captcha', ''), 
                            error="Password and Confirm Password do not match.")
    
    if user_otp != session.get('otp', ''):
        return render_template('registration.html', captcha=session.get('captcha', ''), 
                            error="Invalid OTP. Please try again.")
    
    if user_captcha != session.get('captcha', ''):
        return render_template('registration.html', captcha=session.get('captcha', ''), 
                            error="Invalid CAPTCHA. Please try again.")
    
    # Check if a captured frame exists
    saved_frames = [f for f in os.listdir(output_dir) if f.startswith("frame_")]
    if not saved_frames:
        return render_template('registration.html', captcha=session.get('captcha', ''), 
                            error="Please capture your face frame before registering.")
    
    # Use only one frame (the first one) for registering
    src = os.path.join(output_dir, saved_frames[0])
    dst = os.path.join(registered_faces_dir, f"{uid}.jpg")
    os.replace(src, dst)

    # Remove any other frames to clear storage
    for f in saved_frames[1:]:
        os.remove(os.path.join(output_dir, f))
        
    # Save registration data to Excel file
    data = {
        'Name': [name],
        'UID': [uid],
        'Email': [email],
        'Phone': [phone],
        'Password': [password]  # Warning: storing passwords as plain text is insecure! For demo only.
    }
    df = pd.DataFrame(data)
    file_path = 'registration_data.xlsx'

    try:
        if os.path.exists(file_path):
            with pd.ExcelWriter(file_path, mode='a', engine='openpyxl', if_sheet_exists='overlay') as writer:
                workbook = writer.book
                if 'Registrations' in workbook.sheetnames:
                    sheet = workbook['Registrations']
                    startrow = sheet.max_row
                else:
                    startrow = 0
                df.to_excel(writer, sheet_name='Registrations', index=False, header=False, startrow=startrow)
        else:
            with pd.ExcelWriter(file_path, mode='w', engine='openpyxl') as writer:
                df.to_excel(writer, sheet_name='Registrations', index=False)
    except Exception as e:
        return render_template('registration.html', captcha=session.get('captcha', ''), 
                            error=f"Failed to save registration data: {str(e)}")

    try:
        subject = 'Registration Successful'
        body = f'Thank you for registering, {name}! Your account has been successfully created.'
        send_email(email, subject, body)
    except Exception as e:
        return render_template('registration.html', captcha=session.get('captcha', ''), 
                            error=f"Failed to send confirmation email: {str(e)}")
    
    session.pop('otp', None)
    session.pop('captcha', None)

    return render_template('thank_you.html', name=name, email=email)

@app.route('/verify_password', methods=['POST'])
def verify_password():
    data = request.get_json()
    name = data.get('name', '').strip()
    uid = data.get('uid', '').strip()
    password = data.get('password', '')
    
    if not all([name, uid, password]):
        return jsonify({'success': False, 'message': 'Missing required fields'}), 400
    
    # Load registration data and validate password
    file_path = 'registration_data.xlsx'
    try:
        if not os.path.exists(file_path):
            return jsonify({'success': False, 'message': 'User data not found'}), 404
            
        df = pd.read_excel(file_path, sheet_name='Registrations')
        user_data = df[(df['Name'] == name) & (df['UID'] == uid)]
        
        if user_data.empty:
            return jsonify({'success': False, 'message': 'User not found'}), 404
            
        stored_password = user_data.iloc[0]['Password']
        
        if password == stored_password:
            # In a real application, you would set session variables here
            # instead of passing user information in the URL
            email = user_data.iloc[0]['Email']
            redirect_url = f'/dashboard?name={name}&uid={uid}&email={email}'
            return jsonify({'success': True, 'redirect_url': redirect_url})
        else:
            return jsonify({'success': False, 'message': 'Incorrect password'}), 401
    except Exception as e:
        print(f"Error verifying password: {e}")
        return jsonify({'success': False, 'message': 'Server error during verification'}), 500

@app.route('/update_password', methods=['POST'])
def update_password():
    data = request.get_json()
    name = data.get('name', '').strip()
    uid = data.get('uid', '').strip()
    current_password = data.get('current_password', '')
    new_password = data.get('new_password', '')
    
    if not all([name, uid, current_password, new_password]):
        return jsonify({'success': False, 'message': 'Missing required fields'}), 400
    
    # Load registration data and validate current password
    file_path = 'registration_data.xlsx'
    try:
        if not os.path.exists(file_path):
            return jsonify({'success': False, 'message': 'User data not found'}), 404
            
        df = pd.read_excel(file_path, sheet_name='Registrations')
        user_data = df[(df['Name'] == name) & (df['UID'] == uid)]
        
        if user_data.empty:
            return jsonify({'success': False, 'message': 'User not found'}), 404
            
        # Get the row index for the user
        user_index = user_data.index[0]
        stored_password = user_data.iloc[0]['Password']
        
        # Verify current password
        if current_password != stored_password:
            return jsonify({'success': False, 'message': 'Incorrect current password'}), 401
        
        # Update the password in the DataFrame
        df.at[user_index, 'Password'] = new_password
        
        # Save the updated DataFrame back to Excel
        with pd.ExcelWriter(file_path, mode='w', engine='openpyxl') as writer:
            df.to_excel(writer, sheet_name='Registrations', index=False)
        
        # Send confirmation email
        try:
            email = user_data.iloc[0]['Email']
            subject = 'Password Updated'
            body = f'Hello {name},\n\nYour password has been successfully updated.'
            send_email(email, subject, body)
        except Exception as e:
            print(f"Failed to send password update email: {e}")
            # Continue even if email fails - password is already updated
        
        return jsonify({'success': True, 'message': 'Password updated successfully'})
    except Exception as e:
        print(f"Error updating password: {e}")
        return jsonify({'success': False, 'message': f'Server error during password update: {str(e)}'}), 500

@app.route('/delete_account', methods=['POST', 'DELETE'])
def delete_account():
    # Handle both JSON data (for AJAX requests) and form data
    if request.is_json:
        data = request.get_json()
    else:
        data = request.form.to_dict()
    
    uid = data.get('uid', '').strip()
    email = data.get('email', '').strip()
    
    if not uid or not email:
        return jsonify({'success': False, 'message': 'User ID and email are required'}), 400
        
    # Load registration data
    file_path = 'registration_data.xlsx'
    try:
        if not os.path.exists(file_path):
            return jsonify({'success': False, 'message': 'User data not found'}), 404
            
        df = pd.read_excel(file_path, sheet_name='Registrations')
        user_data = df[df['UID'] == uid]
        
        if user_data.empty:
            return jsonify({'success': False, 'message': 'User not found'}), 404
            
        # Verify email matches the UID
        if user_data.iloc[0]['Email'] != email:
            return jsonify({'success': False, 'message': 'Email does not match user record'}), 400
            
        # Delete user's face image if it exists
        face_image_path = os.path.join(registered_faces_dir, f"{uid}.jpg")
        if os.path.exists(face_image_path):
            os.remove(face_image_path)
            print(f"Deleted face image: {face_image_path}")
            
        # Remove user from the DataFrame
        df = df[df['UID'] != uid]
        
        # Save the updated DataFrame back to Excel
        with pd.ExcelWriter(file_path, mode='w', engine='openpyxl') as writer:
            if not df.empty:
                df.to_excel(writer, sheet_name='Registrations', index=False)
            else:
                # If the DataFrame is empty, create an empty sheet
                pd.DataFrame(columns=['Name', 'UID', 'Email', 'Phone', 'Password']).to_excel(
                    writer, sheet_name='Registrations', index=False)
        
        # Send confirmation email
        try:
            name = user_data.iloc[0]['Name']
            subject = 'Account Deleted'
            body = f'Hello {name},\n\nYour account has been successfully deleted from our system.\n\nIf you did not request this deletion, please contact support immediately.'
            send_email(email, subject, body)
            print(f"Account deletion confirmation email sent to {email}")
        except Exception as e:
            print(f"Failed to send account deletion email: {e}")
            # Continue even if email fails - account is already deleted
        
        # Clean up any login capture files for this user
        for f in os.listdir(output_dir):
            if f.startswith("login_capture_"):
                try:
                    os.remove(os.path.join(output_dir, f))
                except Exception as e:
                    print(f"Warning: Could not delete login capture file {f}: {e}")
        
        return jsonify({
            'success': True, 
            'message': 'Account deleted successfully',
            'deleted_uid': uid
        })
        
    except Exception as e:
        print(f"Error deleting account: {e}")
        return jsonify({
            'success': False, 
            'message': f'Server error during account deletion: {str(e)}'
        }), 500

# Video feed generator for camera streaming
def gen_frames():
    global cap
    try:
        while True:
            if not ensure_camera_is_open():
                yield (b'--frame\r\n'
                    b'Content-Type: text/plain\r\n\r\n' + b'Camera not available. Please check permissions.' + b'\r\n')
                break
                
            success, frame = cap.read()
            if not success:
                continue

            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)

            for (x, y, w, h) in faces:
                cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

            ret, buffer = cv2.imencode('.jpg', frame)
            frame_bytes = buffer.tobytes()

            yield (b'--frame\r\n'
                b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')
    except GeneratorExit:
        if cap.isOpened():
            cap.release()
    except Exception as e:
        print(f"Exception in gen_frames: {e}")
        if cap.isOpened():
            cap.release()
        raise

@app.route('/video_feed')
def video_feed():
    # Make sure the camera is available before generating frames
    if not ensure_camera_is_open():
        # Return an error message if camera isn't available
        return Response("Camera not available. Please check camera permissions.", mimetype='text/plain')
    
    return Response(gen_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

# Save captured frame during registration (only one frame)
@app.route('/save_frame_register')
def save_frame_register():
    if not ensure_camera_is_open():
        return "Camera is not available. Please refresh the page and check camera permissions.", 500

    try:
        ret, frame = cap.read()
        if not ret:
            return "Failed to capture frame from camera", 500

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)
        if len(faces) == 0:
            return "No face detected in frame. Please position your face in the camera view.", 400

        # Clear existing frames first
        for f in os.listdir(output_dir):
            if f.startswith("frame_"):
                os.remove(os.path.join(output_dir, f))

        cv2.imwrite(os.path.join(output_dir, "frame_0.jpg"), frame)
        return "Frame saved successfully", 200
    except Exception as e:
        print(f"Exception in save_frame_register: {e}")
        return f"Error capturing image: {str(e)}", 500

# Modified: Save captured frame during login to the captured_faces folder
@app.route('/save_frame_login')
def save_frame_login():
    if not ensure_camera_is_open():
        return "Camera is not available. Please refresh the page and check camera permissions.", 500

    try:
        ret, frame = cap.read()
        if not ret:
            return "Failed to capture frame from camera", 500

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)
        if len(faces) == 0:
            return "No face detected in frame. Please position your face in the camera view.", 400

        # Clear existing login captures first
        for f in os.listdir(output_dir):
            if f.startswith("login_capture_"):
                os.remove(os.path.join(output_dir, f))

        # Save to the captured_faces folder with timestamp in filename
        login_capture_path = os.path.join(output_dir, f"login_capture_{int(time.time())}.jpg")
        cv2.imwrite(login_capture_path, frame)
        
        # Store the path in session for later verification
        session['login_capture_path'] = login_capture_path
        
        return "Face captured successfully", 200
    except Exception as e:
        print(f"Exception in save_frame_login: {e}")
        return f"Error capturing image: {str(e)}", 500

# Modified: Verify face function using the captured face in captured_faces folder
@app.route('/verify_face', methods=['POST'])
def verify_face():
    data = request.get_json()
    name = data.get('name', '').strip()
    uid = data.get('uid', '').strip()

    if not name or not uid:
        return jsonify({'success': False, 'message': 'Name and UID are required'}), 400

    # Use the saved path from the session
    login_capture_path = session.get('login_capture_path')
    if not login_capture_path or not os.path.exists(login_capture_path):
        return jsonify({'success': False, 'message': 'No face captured for verification'}), 400

    reg_face_path = os.path.join(registered_faces_dir, f"{uid}.jpg")
    if not os.path.exists(reg_face_path):
        return jsonify({'success': False, 'message': 'No registered face data found for this user'}), 404

    if is_face_matching(login_capture_path, reg_face_path):
        return jsonify({'success': True, 'message': 'Face verified successfully'})

    return jsonify({'success': False, 'message': 'Face verification failed'})

@app.route('/login', methods=['POST'])
def login():
    # For form data submission
    if request.form:
        name = request.form.get('name', '').strip()
        uid = request.form.get('uid', '').strip()
    # For JSON data submission
    else:
        data = request.get_json() or {}
        name = data.get('name', '').strip()
        uid = data.get('uid', '').strip()
    
    if not name or not uid:
        return jsonify({'success': False, 'message': 'Name and UID are required'}), 400
    
    # Check if user exists in the registration data
    file_path = 'registration_data.xlsx'
    if not os.path.exists(file_path):
        return jsonify({'success': False, 'message': 'User data not found'}), 404
        
    try:
        df = pd.read_excel(file_path, sheet_name='Registrations')
        user_exists = not df[(df['Name'] == name) & (df['UID'] == uid)].empty
        
        if user_exists:
            return jsonify({'success': True})
        else:
            return jsonify({'success': False, 'message': 'User not found'}), 404
    except Exception as e:
        print(f"Error checking user: {e}")
        return jsonify({'success': False, 'message': 'Error checking user credentials'}), 500

@app.route('/logout')
def logout():
    # In a real application, you would clear session data here
    return redirect('/')

@app.route('/shutdown', methods=['POST', 'GET'])
def shutdown():
    global cap
    if cap.isOpened():
        cap.release()
    return '', 204

if __name__ == "__main__":
    try:
        app.run(debug=True)
    finally:
        if cap.isOpened():
            cap.release()
        cv2.destroyAllWindows()
        sys.exit(0)