// Modified security_password.js file that will redirect to the secure folder dashboard
document.addEventListener('DOMContentLoaded', function() {
    // Get the name and uid from sessionStorage
    const name = sessionStorage.getItem('login_name');
    const uid = sessionStorage.getItem('login_uid');
    
    // Set the hidden form values
    document.getElementById('hiddenName').value = name;
    document.getElementById('hiddenUid').value = uid;
    
    // Password visibility toggle
    const togglePasswordBtn = document.getElementById('togglePassword');
    const passwordInput = document.getElementById('password');
    
    togglePasswordBtn.addEventListener('click', function() {
        const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
        passwordInput.setAttribute('type', type);
        this.classList.toggle('show');
    });
    
    // Form submission
    const securityPasswordForm = document.getElementById('securityPasswordForm');
    const errorMessageDiv = document.getElementById('errorMessage');
    
    securityPasswordForm.addEventListener('submit', function(e) {
        e.preventDefault();
        errorMessageDiv.textContent = '';
        
        const password = passwordInput.value.trim();
        
        if (!password) {
            errorMessageDiv.textContent = 'Please enter your security password.';
            return;
        }
        
        // Send the data to the server
        fetch('/verify_password', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                name: name,
                uid: uid,
                password: password
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Get email from the redirect URL
                const emailMatch = data.redirect_url.match(/email=([^&]*)/);
                const email = emailMatch ? decodeURIComponent(emailMatch[1]) : '';
                
                // Store password hash for secure folder system
                const simpleHash = function(str) {
                    let hash = 0;
                    for (let i = 0; i < str.length; i++) {
                        const char = str.charCodeAt(i);
                        hash = ((hash << 5) - hash) + char;
                        hash = hash & hash;
                    }
                    return hash.toString(16);
                };
                
                // Set up the secure folder for this user
                const userStorageKey = `secureFolder_${uid}`;
                if (!localStorage.getItem(`${userStorageKey}_passwordHash`)) {
                    localStorage.setItem(`${userStorageKey}_passwordHash`, simpleHash(password));
                    localStorage.setItem(`${userStorageKey}_files`, JSON.stringify([]));
                }
                
                // Redirect to dashboard with secure folder system
                window.location.href = data.redirect_url;
            } else {
                errorMessageDiv.textContent = data.message || 'Invalid security password. Please try again.';
            }
        })
        .catch(error => {
            errorMessageDiv.textContent = 'An error occurred. Please try again.';
            console.error('Error:', error);
        });
    });
});