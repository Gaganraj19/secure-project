document.addEventListener('DOMContentLoaded', () => {
    // Get URL parameters for user info
    const urlParams = new URLSearchParams(window.location.search);
    const name = urlParams.get('name') || 'User';
    const uid = urlParams.get('uid') || '';
    const email = urlParams.get('email') || '';

    // Set user information
    document.getElementById('welcomeMessage').textContent = `Welcome, ${name}`;
    document.getElementById('userEmail').textContent = email;
    document.getElementById('userId').textContent = `ID: ${uid}`;
    document.getElementById('profileName').textContent = name;
    document.getElementById('profileId').textContent = uid;
    document.getElementById('profileEmail').textContent = email;

    // Set user avatar with first letter of name
    const userAvatar = document.getElementById('userAvatar');
    userAvatar.textContent = name.charAt(0).toUpperCase();

    // Tab switching
    const tabs = document.querySelectorAll('.tab');
    tabs.forEach((tab) => {
        tab.addEventListener('click', () => {
            // Remove active class from all tabs and content
            document.querySelectorAll('.tab').forEach((t) => t.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach((c) => c.classList.remove('active'));

            // Add active class to clicked tab and corresponding content
            tab.classList.add('active');
            const tabContent = document.getElementById(tab.dataset.tab);
            tabContent.classList.add('active');
        });
    });

    // Change password button in settings
    document.getElementById('changePasswordBtn').addEventListener('click', () => {
        document.getElementById('reset-password-dialog').style.display = 'flex';
    });

    // DOM elements for secure folder system
    const folderView = document.getElementById('folder-view');
    const resetPasswordBtn = document.getElementById('reset-password-btn');
    const fileGrid = document.getElementById('file-grid');
    const importBtn = document.getElementById('import-btn');
    const fileInput = document.getElementById('file-input');
    const searchInput = document.getElementById('search');
    const contextMenu = document.getElementById('context-menu');
    const alertContainer = document.getElementById('alert-container');

    // Application state
    let files = [];
    let currentFileIndex = null;

    // Initialize secure folder system
    const userStorageKey = `secureFolder_${uid}`;
    loadFiles(userStorageKey);
    renderFiles();

    // Event Listeners
    if (resetPasswordBtn) {
        resetPasswordBtn.addEventListener('click', showResetPasswordDialog);
    }
    if (importBtn) {
        importBtn.addEventListener('click', () => fileInput.click());
    }
    if (fileInput) {
        fileInput.addEventListener('change', handleFileImport);
    }
    if (searchInput) {
        searchInput.addEventListener('input', handleSearch);
    }

    // Reset Password Dialog event listeners
    const cancelResetBtn = document.getElementById('cancel-reset-btn');
    const confirmResetBtn = document.getElementById('confirm-reset-btn');
    
    if (cancelResetBtn) {
        cancelResetBtn.addEventListener('click', hideResetPasswordDialog);
    }
    if (confirmResetBtn) {
        confirmResetBtn.addEventListener('click', () => handlePasswordReset(userStorageKey));
    }

    showAlert('Secure folder system activated', 'success');

    // Show reset password dialog
    function showResetPasswordDialog() {
        const resetDialog = document.getElementById('reset-password-dialog');
        if (resetDialog) {
            resetDialog.style.display = 'flex';

            // Reset form fields
            const currentPasswordField = document.getElementById('current-password');
            const newPasswordField = document.getElementById('new-password');
            const confirmNewPasswordField = document.getElementById('confirm-new-password');
            const resetError = document.getElementById('reset-error');
            
            if (currentPasswordField) currentPasswordField.value = '';
            if (newPasswordField) newPasswordField.value = '';
            if (confirmNewPasswordField) confirmNewPasswordField.value = '';
            if (resetError) resetError.classList.add('hidden');
        }
    }

    // Hide reset password dialog
    function hideResetPasswordDialog() {
        const resetDialog = document.getElementById('reset-password-dialog');
        if (resetDialog) {
            resetDialog.style.display = 'none';
        }
    }

    // Handle password reset
    function handlePasswordReset(userStorageKey) {
        const currentPassword = document.getElementById('current-password')?.value;
        const newPassword = document.getElementById('new-password')?.value;
        const confirmNewPassword = document.getElementById('confirm-new-password')?.value;
        const resetError = document.getElementById('reset-error');

        // Verify current password by sending to server
        fetch('/verify_password', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                name: name,
                uid: uid,
                password: currentPassword,
            }),
        })
            .then((response) => response.json())
            .then((data) => {
                if (!data.success) {
                    if (resetError) {
                        resetError.classList.remove('hidden');
                        const errorText = resetError.querySelector('p');
                        if (errorText) {
                            errorText.textContent = 'Current password is incorrect.';
                        }
                    }
                    return;
                }

                // Check if new passwords match
                if (!newPassword || newPassword !== confirmNewPassword) {
                    if (resetError) {
                        resetError.classList.remove('hidden');
                        const errorText = resetError.querySelector('p');
                        if (errorText) {
                            errorText.textContent = 'New passwords do not match or are empty.';
                        }
                    }
                    return;
                }

                // Send password update to server
                fetch('/update_password', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        name: name,
                        uid: uid,
                        current_password: currentPassword,
                        new_password: newPassword,
                    }),
                })
                    .then(res => res.json())
                    .then(updateData => {
                        if (updateData.success) {
                            hideResetPasswordDialog();
                            showAlert('Password has been reset successfully', 'success');
                        } else {
                            if (resetError) {
                                resetError.classList.remove('hidden');
                                const errorText = resetError.querySelector('p');
                                if (errorText) {
                                    errorText.textContent = updateData.message || 'Password change failed.';
                                }
                            }
                        }
                    })
                    .catch(error => {
                        console.error('Error updating password:', error);
                        if (resetError) {
                            resetError.classList.remove('hidden');
                            const errorText = resetError.querySelector('p');
                            if (errorText) {
                                errorText.textContent = 'An error occurred while updating password. Please try again.';
                            }
                        }
                    });
            })
            .catch((error) => {
                console.error('Error:', error);
                if (resetError) {
                    resetError.classList.remove('hidden');
                    const errorText = resetError.querySelector('p');
                    if (errorText) {
                        errorText.textContent = 'An error occurred. Please try again.';
                    }
                }
            });
    }

    // Handle file import
    function handleFileImport(e) {
        const selectedFiles = Array.from(e.target.files);
        if (selectedFiles.length === 0) return;

        selectedFiles.forEach((file) => {
            const reader = new FileReader();

            reader.onload = function (event) {
                const fileData = {
                    id: Date.now() + Math.random().toString(36).substring(2, 10),
                    name: file.name,
                    type: file.type,
                    size: file.size,
                    lastModified: file.lastModified,
                    content: event.target.result,
                    createdAt: new Date().toISOString(),
                };

                files.push(fileData);
                saveFiles(userStorageKey);
                renderFiles();
            };

            reader.readAsDataURL(file);
        });

        // Clear the input so the same file can be imported again
        fileInput.value = '';
        showAlert(`Imported ${selectedFiles.length} file(s) successfully`, 'success');
    }

    // Save files (using in-memory storage for demo)
    function saveFiles(userStorageKey) {
        // In a real application, this would save to a server
        // For demo purposes, we'll use a simple variable storage
        window.userFiles = files;
    }

    // Load files (using in-memory storage for demo)
    function loadFiles(userStorageKey) {
        // In a real application, this would load from server
        // For demo purposes, we'll use a simple variable storage
        files = window.userFiles || [];
    }

    // Render files in the grid
    function renderFiles(filteredFiles = null) {
        if (!fileGrid) return;
        
        const filesToRender = filteredFiles || files;
        fileGrid.innerHTML = '';

        if (filesToRender.length === 0) {
            fileGrid.innerHTML =
                '<div class="empty-state">No files found. Import files to get started.</div>';
            return;
        }

        filesToRender.forEach((file, index) => {
            const fileItem = document.createElement('div');
            fileItem.className = 'file-item';
            fileItem.dataset.id = file.id;
            fileItem.dataset.index = index;

            // Determine file icon based on type
            let iconText = '📄';
            if (file.type.startsWith('image/')) iconText = '🖼️';
            else if (file.type.startsWith('video/')) iconText = '🎬';
            else if (file.type.startsWith('audio/')) iconText = '🎵';
            else if (file.type.includes('pdf')) iconText = '📕';
            else if (file.type.includes('excel') || file.type.includes('spreadsheet'))
                iconText = '📊';
            else if (file.type.includes('word') || file.type.includes('document'))
                iconText = '📝';

            fileItem.innerHTML = `
                <div class="file-icon">${iconText}</div>
                <div class="file-name">${file.name}</div>
            `;

            // Add event listeners for file interaction
            fileItem.addEventListener('click', () => {
                // Download or preview the file
                downloadFile(file);
            });

            fileItem.addEventListener('contextmenu', (e) => {
                e.preventDefault();
                showContextMenu(e, index);
            });

            fileGrid.appendChild(fileItem);
        });
    }

    // Search files
    function handleSearch() {
        if (!searchInput) return;
        
        const searchTerm = searchInput.value.toLowerCase();

        if (!searchTerm) {
            renderFiles();
            return;
        }

        const filtered = files.filter((file) =>
            file.name.toLowerCase().includes(searchTerm)
        );

        renderFiles(filtered);
    }

    // Show context menu
    function showContextMenu(e, fileIndex) {
        if (!contextMenu) return;
        
        e.preventDefault();
        currentFileIndex = fileIndex;

        contextMenu.style.display = 'block';
        contextMenu.style.left = `${e.pageX}px`;
        contextMenu.style.top = `${e.pageY}px`;

        // Add event listeners to menu items
        const menuItems = contextMenu.querySelectorAll('.menu-item');
        menuItems.forEach((item) => {
            item.onclick = () => handleContextMenuAction(item.dataset.action);
        });

        // Close menu when clicking elsewhere
        document.addEventListener('click', closeContextMenu);
    }

    // Close context menu
    function closeContextMenu() {
        if (contextMenu) {
            contextMenu.style.display = 'none';
        }
        document.removeEventListener('click', closeContextMenu);
    }

    // Handle context menu actions
    function handleContextMenuAction(action) {
        const file = files[currentFileIndex];

        switch (action) {
            case 'download':
                downloadFile(file);
                break;
            case 'rename':
                const newName = prompt('Enter new filename:', file.name);
                if (newName && newName !== file.name) {
                    files[currentFileIndex].name = newName;
                    saveFiles(userStorageKey);
                    renderFiles();
                    showAlert('File renamed successfully', 'success');
                }
                break;
            case 'delete':
                if (confirm(`Are you sure you want to delete "${file.name}"?`)) {
                    files.splice(currentFileIndex, 1);
                    saveFiles(userStorageKey);
                    renderFiles();
                    showAlert('File deleted successfully', 'success');
                }
                break;
        }
        closeContextMenu();
    }

    // Download file
    function downloadFile(file) {
        const link = document.createElement('a');
        link.href = file.content;
        link.download = file.name;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    // Display alert message
    function showAlert(message, type) {
        if (!alertContainer) return;
        
        const alertElement = document.createElement('div');
        alertElement.className = `alert alert-${type}`;
        alertElement.innerHTML = `<p>${message}</p>`;

        alertContainer.innerHTML = '';
        alertContainer.appendChild(alertElement);

        // Auto-hide after 3 seconds
        setTimeout(() => {
            if (alertElement.parentNode) {
                alertElement.remove();
            }
        }, 3000);
    }

    // Delete account function with confirmation dialog and redirect
    const deleteAccountBtn = document.getElementById('deleteAccountBtn');
    if (deleteAccountBtn) {
        deleteAccountBtn.addEventListener('click', () => {
            // Show custom confirmation dialog
            const deleteDialog = document.getElementById('delete-confirmation-dialog');
            if (deleteDialog) {
                deleteDialog.style.display = 'flex';
            }
        });
    }

    // Cancel delete account
    const cancelDeleteBtn = document.getElementById('cancel-delete-btn');
    if (cancelDeleteBtn) {
        cancelDeleteBtn.addEventListener('click', () => {
            const deleteDialog = document.getElementById('delete-confirmation-dialog');
            if (deleteDialog) {
                deleteDialog.style.display = 'none';
            }
        });
    }

    // Confirm delete account
    const confirmDeleteBtn = document.getElementById('confirm-delete-btn');
    if (confirmDeleteBtn) {
        confirmDeleteBtn.addEventListener('click', () => {
            const deleteBtn = document.getElementById('confirm-delete-btn');
            const cancelBtn = document.getElementById('cancel-delete-btn');
            
            // Show loading state
            if (deleteBtn) {
                deleteBtn.textContent = 'Deleting...';
                deleteBtn.disabled = true;
            }
            if (cancelBtn) {
                cancelBtn.disabled = true;
            }
            
            // Send delete request to server
            fetch('/delete_account', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    uid: uid,
                    email: email,
                    name: name
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Clear any stored data
                    if (typeof window.userFiles !== 'undefined') {
                        delete window.userFiles;
                    }
                    
                    // Hide the confirmation dialog
                    const deleteDialog = document.getElementById('delete-confirmation-dialog');
                    if (deleteDialog) {
                        deleteDialog.style.display = 'none';
                    }
                    
                    // Show success message and start countdown
                    showAlert('Account deleted successfully. Redirecting to registration...', 'success');
                    
                    // Create countdown overlay
                    const countdownOverlay = document.createElement('div');
                    countdownOverlay.className = 'countdown-overlay';
                    
                    const countdownContent = document.createElement('div');
                    countdownContent.className = 'countdown-content';
                    countdownContent.innerHTML = `
                        <div style="margin-bottom: 20px; font-size: 28px;">✅ Account Deleted Successfully</div>
                        <div style="font-size: 18px;">Redirecting to registration page in</div>
                        <div class="countdown-number" id="countdown-number">5</div>
                        <div style="font-size: 16px; opacity: 0.8;">seconds...</div>
                    `;
                    
                    countdownOverlay.appendChild(countdownContent);
                    document.body.appendChild(countdownOverlay);
                    
                    // Start countdown
                    let countdown = 5;
                    const countdownElement = document.getElementById('countdown-number');
                    
                    const countdownInterval = setInterval(() => {
                        countdown--;
                        if (countdownElement) {
                            countdownElement.textContent = countdown;
                        }
                        
                        if (countdown <= 0) {
                            clearInterval(countdownInterval);
                            // Redirect to registration page - use the correct Flask route
                            window.location.href = '/register';  // Changed from 'login.html' to '/register'
                        }
                    }, 1000);
                    
                } else {
                    // Handle deletion failure
                    showAlert(data.message || 'Failed to delete account. Please try again.', 'danger');
                    
                    // Re-enable buttons
                    if (deleteBtn) {
                        deleteBtn.textContent = 'Yes, Delete My Account';
                        deleteBtn.disabled = false;
                    }
                    if (cancelBtn) {
                        cancelBtn.disabled = false;
                    }
                }
            })
            .catch(error => {
                console.error('Error deleting account:', error);
                showAlert('An error occurred while deleting account. Please try again.', 'danger');
                
                // Re-enable buttons
                if (deleteBtn) {
                    deleteBtn.textContent = 'Yes, Delete My Account';
                    deleteBtn.disabled = false;
                }
                if (cancelBtn) {
                    cancelBtn.disabled = false;
                }
            });
        });
    }

    // Initialize dashboard stats (if elements exist)
    const updateDashboardStats = () => {
        const totalFilesElement = document.getElementById('totalFiles');
        const storageUsedElement = document.getElementById('storageUsed');
        const lastLoginElement = document.getElementById('lastLogin');
        
        if (totalFilesElement) {
            totalFilesElement.textContent = files.length;
        }
        
        if (storageUsedElement) {
            const totalSize = files.reduce((sum, file) => sum + (file.size || 0), 0);
            const sizeInMB = (totalSize / (1024 * 1024)).toFixed(2);
            storageUsedElement.textContent = `${sizeInMB} MB`;
        }
        
        if (lastLoginElement) {
            lastLoginElement.textContent = new Date().toLocaleDateString();
        }
    };

    // Update stats initially and when files change
    updateDashboardStats();
    
    // Override the original renderFiles to also update stats
    const originalRenderFiles = renderFiles;
    renderFiles = function(filteredFiles = null) {
        originalRenderFiles(filteredFiles);
        if (!filteredFiles) { // Only update stats when showing all files
            updateDashboardStats();
        }
    };

    // Logout functionality
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
            if (confirm('Are you sure you want to logout?')) {
                // Clear any stored data
                if (typeof window.userFiles !== 'undefined') {
                    delete window.userFiles;
                }
                
                showAlert('Logging out...', 'info');
                
                // Redirect to login after a short delay - use correct Flask route
                setTimeout(() => {
                    window.location.href = '/';  // Changed from 'login.html' to '/'
                }, 1000);
            }
        });
    }

    // Close dialogs when clicking outside
    document.addEventListener('click', (e) => {
        const resetDialog = document.getElementById('reset-password-dialog');
        const deleteDialog = document.getElementById('delete-confirmation-dialog');
        
        // Close reset password dialog
        if (resetDialog && resetDialog.style.display === 'flex') {
            if (e.target === resetDialog) {
                hideResetPasswordDialog();
            }
        }
        
        // Close delete confirmation dialog
        if (deleteDialog && deleteDialog.style.display === 'flex') {
            if (e.target === deleteDialog) {
                deleteDialog.style.display = 'none';
            }
        }
    });

    // Keyboard shortcuts
    document.addEventListener('keydown', (e) => {
        // Escape key to close dialogs
        if (e.key === 'Escape') {
            const resetDialog = document.getElementById('reset-password-dialog');
            const deleteDialog = document.getElementById('delete-confirmation-dialog');
            
            if (resetDialog && resetDialog.style.display === 'flex') {
                hideResetPasswordDialog();
            }
            
            if (deleteDialog && deleteDialog.style.display === 'flex') {
                deleteDialog.style.display = 'none';
            }
            
            closeContextMenu();
        }
        
        // Ctrl+I for import files
        if (e.ctrlKey && e.key === 'i' && fileInput) {
            e.preventDefault();
            fileInput.click();
        }
        
        // Focus search with Ctrl+F
        if (e.ctrlKey && e.key === 'f' && searchInput) {
            e.preventDefault();
            searchInput.focus();
        }
    });
});