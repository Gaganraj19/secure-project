document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    const errorMessageDiv = document.getElementById('errorMessage');
    const captureBtn = document.getElementById('capture-button');
    const messageDiv = document.getElementById('message');
    
    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        errorMessageDiv.textContent = '';
        
        const name = document.getElementById('name').value.trim();
        const uid = document.getElementById('uid').value.trim();
        
        if (!name || !uid) {
            errorMessageDiv.textContent = 'Please enter both Name and UID.';
            return;
        }
        
        // Store credentials in sessionStorage for face verification
        sessionStorage.setItem('login_name', name);
        sessionStorage.setItem('login_uid', uid);
        
        // Create FormData object for sending form data
        const formData = new FormData();
        formData.append('name', name);
        formData.append('uid', uid);
        
        // Send the form data to verify user exists
        fetch('/login', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                errorMessageDiv.textContent = '';
                messageDiv.style.color = "#4caf50";
                messageDiv.textContent = "User found! Please capture your face for verification.";
            } else {
                errorMessageDiv.textContent = data.message || 'Invalid credentials. Please try again.';
            }
        })
        .catch(error => {
            errorMessageDiv.textContent = 'An error occurred. Please try again.';
            console.error('Error:', error);
        });
    });
    
    // Function to verify face after capture
    function verifyFace() {
        const name = sessionStorage.getItem('login_name');
        const uid = sessionStorage.getItem('login_uid');
        
        if (!name || !uid) {
            messageDiv.style.color = "#e53935";
            messageDiv.textContent = "User credentials not found. Please login again.";
            return;
        }
        
        messageDiv.textContent = "Verifying face...";
        
        fetch('/verify_face', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({name: name, uid: uid})
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                messageDiv.style.color = "#4caf50";
                messageDiv.textContent = "Face verified successfully! Redirecting...";
                // Redirect to security password page
                window.location.href = '/security_password';
            } else {
                messageDiv.style.color = "#e53935";
                messageDiv.textContent = data.message || "Face verification failed.";
            }
        })
        .catch(error => {
            messageDiv.style.color = "#e53935";
            messageDiv.textContent = "Error verifying face. Please try again.";
            console.error('Error:', error);
        });
    }
    
    // Expose verifyFace to the global scope
    window.verifyFace = verifyFace;
    
    // Existing code for face capture
    captureBtn.addEventListener('click', function() {
        // First ensure the user has entered their credentials
        const name = sessionStorage.getItem('login_name');
        const uid = sessionStorage.getItem('login_uid');
        
        if (!name || !uid) {
            messageDiv.style.color = "#e53935";
            messageDiv.textContent = "Please enter your Name and UID first.";
            return;
        }
        
        messageDiv.textContent = "Capturing...";
        
        fetch('/save_frame_login')
            .then(response => {
                if (response.ok) {
                    return response.text().then(text => {
                        messageDiv.style.color = "#4caf50";
                        messageDiv.textContent = text || "Face captured successfully!";
                        // After successful capture, verify the face
                        setTimeout(verifyFace, 1000);
                    });
                } else {
                    return response.text().then(text => {
                        messageDiv.style.color = "#e53935";
                        messageDiv.textContent = text || "Error capturing image.";
                    });
                }
            })
            .catch(error => {
                messageDiv.style.color = "#e53935";
                messageDiv.textContent = "Error capturing face: " + error;
            });
    });
});