// Function to reinitialize camera if needed
function reinitializeCamera() {
    const messageDiv = document.getElementById('message');
    messageDiv.style.color = "#f39c12";
    messageDiv.textContent = "Attempting to reinitialize camera...";
    
    fetch('/reinitialize_camera')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                messageDiv.style.color = "#4caf50";
                messageDiv.textContent = "Camera reinitialized. Please try capturing again.";
                // Reload the video feed
                const videoFeed = document.getElementById('video-feed');
                if (videoFeed) {
                    videoFeed.src = videoFeed.src;
                }
            } else {
                messageDiv.style.color = "#e53935";
                messageDiv.textContent = "Failed to reinitialize camera: " + data.message;
            }
        })
        .catch(error => {
            messageDiv.style.color = "#e53935";
            messageDiv.textContent = "Error reinitializing camera: " + error;
        });
}
function sendOtp(email) {
    return fetch('/send_otp', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({email: email})
    });
}

document.getElementById('sendOtpBtn').addEventListener('click', function() {
    var email = document.getElementById('email').value.trim();
    if(!email) {
        alert('Please enter your email before requesting OTP.');
        return;
    }
    sendOtp(email)
    .then(response => response.json())
    .then(data => {
        if(data.success) {
            document.getElementById('otpInfo').textContent = 'OTP sent to ' + email;
            document.getElementById('sendOtpBtn').style.display = 'none';
            document.getElementById('resendOtpBtn').style.display = 'inline-block';
        } else {
            document.getElementById('otpInfo').textContent = 'Failed to send OTP: ' + data.error;
        }
    })
    .catch(() => {
        document.getElementById('otpInfo').textContent = 'Error sending OTP.';
    });
});

document.getElementById('resendOtpBtn').addEventListener('click', function() {
    var email = document.getElementById('email').value.trim();
    if(!email) {
        alert('Please enter your email before resending OTP.');
        return;
    }
    sendOtp(email)
    .then(response => response.json())
    .then(data => {
        if(data.success) {
            document.getElementById('otpInfo').textContent = 'OTP resent to ' + email;
        } else {
            document.getElementById('otpInfo').textContent = 'Failed to resend OTP: ' + data.error;
        }
    })
    .catch(() => {
        document.getElementById('otpInfo').textContent = 'Error resending OTP.';
    });
});

// CAPTCHA refresh functionality
document.getElementById('refreshCaptcha').addEventListener('click', function() {
    fetch('/refresh_captcha')
    .then(response => response.json())
    .then(data => {
        document.getElementById('captchaCode').textContent = data.captcha;
    });
});

// Form validation
document.getElementById('registrationForm').addEventListener('submit', function(e) {
    var otp = document.getElementById('otp').value.trim();
    var captchaInput = document.getElementById('captcha').value.trim();
    var captchaCode = document.getElementById('captchaCode').textContent.trim();
    var password = document.getElementById('password').value;
    var confirmPassword = document.getElementById('confirm_password').value;
    var errorMessage = '';

    if (!password) {
        errorMessage = 'Please enter a password.';
    } else if (password.length < 8) {
        errorMessage = 'Password must be at least 8 characters.';
    } else if (password !== confirmPassword) {
        errorMessage = 'Passwords do not match.';
    } else if(!otp.match(/^\d{6}$/)) {
        errorMessage = 'Please enter a valid 6-digit OTP.';
    } else if(captchaInput.length !== 6) {
        errorMessage = 'Please enter the 6-character CAPTCHA.';
    } else if(captchaInput !== captchaCode) {
        errorMessage = 'CAPTCHA does not match.';
    }

    if(errorMessage) {
        e.preventDefault();
        document.getElementById('errorMessage').textContent = errorMessage;
    }
});

// Camera capture button functionality
const captureBtn = document.getElementById('capture-button');
const messageDiv = document.getElementById('message');
const videoFeed = document.getElementById('video-feed');

// Check if camera is available when page loads
document.addEventListener('DOMContentLoaded', function() {
    // Ensure the video feed is loaded and accessible
    if (videoFeed) {
        videoFeed.onerror = function() {
            messageDiv.style.color = "#e53935";
            messageDiv.textContent = "Error loading camera feed. Please check camera permissions.";
        };
        
        videoFeed.onload = function() {
            console.log("Camera feed loaded successfully");
        };
    } else {
        console.error("Video feed element not found");
    }
});

captureBtn.addEventListener('click', () => {
    messageDiv.textContent = "Capturing...";
    
    // First check if camera feed is visible/loaded
    if (videoFeed && videoFeed.complete && videoFeed.naturalHeight !== 0) {
        fetch('/save_frame_register')
            .then(response => {
                if (response.ok) {
                    messageDiv.style.color = "#4caf50";
                    messageDiv.textContent = "Face captured!";
                } else {
                    response.text().then(text => {
                        messageDiv.style.color = "#e53935";
                        messageDiv.textContent = text || "Error capturing image.";
                    });
                }
            }).catch((error) => {
                messageDiv.style.color = "#e53935";
                messageDiv.textContent = "Error capturing face: " + (error.message || "Unknown error");
                console.error("Capture error:", error);
                
                // Add a button to reinitialize camera
                const reinitButton = document.createElement('button');
                reinitButton.textContent = "Reinitialize Camera";
                reinitButton.className = "button";
                reinitButton.style = "margin-top: 10px; background-color: #f39c12;";
                reinitButton.onclick = reinitializeCamera;
                
                // Add button after the message div
                messageDiv.parentNode.insertBefore(reinitButton, messageDiv.nextSibling);
            });
    } else {
        messageDiv.style.color = "#e53935";
        messageDiv.textContent = "Camera not ready or not available. Please refresh the page and ensure camera permissions are granted.";
        
        // Add a button to reinitialize camera
        const reinitButton = document.createElement('button');
        reinitButton.textContent = "Reinitialize Camera";
        reinitButton.className = "button";
        reinitButton.style = "margin-top: 10px; background-color: #f39c12;";
        reinitButton.onclick = reinitializeCamera;
        
        // Add button after the message div
        messageDiv.parentNode.insertBefore(reinitButton, messageDiv.nextSibling);
    }
});